// TestApp.cs
//
// This application performs some fairly simply demonstrations of the custom
// DevelopMentor.ThreadPool class (see ThreadPool.cs).
//
// Mike Woodring
// http://staff.develop.com/woodring
//
using System;
using System.Threading;

class App
{
    static void Main( string[] args )
    {
        // Parse any arguments (optional iteration count).
        //
        int REQUEST_COUNT = (args.Length > 0 ? int.Parse(args[0]) : 20);

        Console.WriteLine("Main called on thread {0}", AppDomain.GetCurrentThreadId());

        // Thread pool 1 will be a low priority thread pool with a new thread
        // trigger of 400ms.  The callbacks below will suspend the calling
        // thread for a random amount of time between 100 and 500 ms.  A
        // short (5 second) dynamic thread decay time is used just to facilitate
        // testing and monitoring from taskmgr.  The default dynamic thread
        // decay time is 5 minutes.
        //
        DevelopMentor.ThreadPool tp1 = new DevelopMentor.ThreadPool(2, 6, "Pool1");
        tp1.Priority = System.Threading.ThreadPriority.BelowNormal;
        tp1.NewThreadTrigger = 400;
        tp1.DynamicThreadDecay = 5000;

        // Thread pool 2 will be a high priority thread pool with a new thread
        // trigger or 250ms.
        //
        DevelopMentor.ThreadPool tp2 = new DevelopMentor.ThreadPool(2, 4, "Pool2");
        tp2.Priority = System.Threading.ThreadPriority.AboveNormal;
        tp2.NewThreadTrigger = 250;
        tp2.DynamicThreadDecay = 5000;

        // Wire up a delegate conforming to the thread pool's early bound
        // WorkRequestDelegate signagure.
        //
        DevelopMentor.WorkRequestDelegate cb1 = new DevelopMentor.WorkRequestDelegate(CallbackOne);

        // Wire up a delegate of our own choosing.
        //
        SomeDelegate cb2 = new SomeDelegate(CallbackTwo);

        // The entire test is done three times to test
        // stop/start functionality.
        //
        for( int testRun = 0; testRun < 3; testRun++ )
        {
            Console.WriteLine("Press ENTER to start test");
            Console.ReadLine();

            tp1.Start();
            tp2.Start();

            // Post REQUEST_COUNT requests to thread pool #1.
            //
            for( int n = 0; n < REQUEST_COUNT; n++ )
            {
                string arg = string.Format("REQ-{0}", n+1);

                // This tests the simplified usage model using the
                // early bound DPCQueue.WorkProc delegate to indicate the
                // target method to call.
                //
                tp1.PostRequest(cb1, arg);

                // Post every other request to thread pool #2 as well.
                //
                if( (n % 2) == 0 )
                {
                    // This tests the dynamic invocation model that's akin
                    // to Control.Invoke/BeginInvoke - where you just specify
                    // a generate instance of System.Delegate as the target,
                    // and an array (possibly empty) of arguments to that
                    // target method.  The elements in the array need to match,
                    // in left-to-right order, the type and number of arguments
                    // the target method expects to receive.
                    //
                    object[] callbackArgs = { arg, (double)100.0 + n, DateTime.Now };
                    tp2.PostRequest(cb2, callbackArgs);
                }
            }

            Console.WriteLine("Press ENTER to stop the thread pools");
            Console.ReadLine();

            Console.Write("Stopping thread pools...");

            tp1.StopAndWait();
            tp2.StopAndWait();

            Console.WriteLine("done.");
            Console.WriteLine("Calls to callback 1: expected {0}, received {1}", REQUEST_COUNT, callbackOneCount);
            Console.WriteLine("Calls to callback 2: expected {0}, received {1}", REQUEST_COUNT / 2, callbackTwoCount);

            callbackOneCount = callbackTwoCount = 0;
        }
    }

    static int callbackOneCount = 0;
    static int callbackTwoCount = 0;
    static Random rng = new Random();

    static void CallbackOne( object state, DateTime requestEnqueueTime )
    {
        Interlocked.Increment(ref callbackOneCount);

        DateTime now = DateTime.Now;

        // Compute a sleep interval for a random amount of time
        // between 100ms and 500ms.  The Random class is not
        // thread safe, so we need to do a little locking from
        // the outside.
        //
        int sleepInterval;

        lock( rng )
        {
            sleepInterval = rng.Next(100, 500);
        }

        Console.WriteLine( "CallbackOne called:\n" +
                           "  Thread id:            {0}\n" +
                           "  Thread name:          {1}\n" +
                           "  State argument:       {2}\n" +
                           "  Request enqueue time: {3}\n" +
                           "  Current time:         {4}\n" +
                           "  Elapsed time:         {5}\n" +
                           "  Sleep interval (ms):  {6}",
                           AppDomain.GetCurrentThreadId(),
                           System.Threading.Thread.CurrentThread.Name,
                           (string)state,
                           requestEnqueueTime,
                           now,
                           now.Subtract(requestEnqueueTime),
                           sleepInterval );

        // Do the sleep.
        Thread.Sleep(sleepInterval);

        // Note that we're done (displaying the thread id/name & sleep
        // interval so that this output can be correlated to the previous
        // bit of output before the sleep.
        //
        Console.WriteLine( "CallbackOne returning:\n" +
                           "  Thread id:            {0}\n" +
                           "  Thread name:          {1}\n" +
                           "  Sleep interval (ms):  {2}",
                           AppDomain.GetCurrentThreadId(),
                           System.Threading.Thread.CurrentThread.Name,
                           sleepInterval );
    }

    delegate void SomeDelegate( string s, double d, DateTime requestEnqueueTime  );

    static void CallbackTwo( string s, double d, DateTime requestEnqueueTime )
    {
        Interlocked.Increment(ref callbackTwoCount);

        DateTime now = DateTime.Now;

        // Compute a sleep interval for a random amount of time
        // between 100ms and 500ms.  The Random class is not
        // thread safe, so we need to do a little locking from
        // the outside.
        //
        int sleepInterval;

        lock( rng )
        {
            sleepInterval = rng.Next(100, 500);
        }

        Console.WriteLine( "CallbackTwo called:\n" +
                           "  Thread id:           {0}\n" +
                           "  Thread name:         {1}\n" +
                           "  Arguments:           s = {2}, d = {3}, reqEnqTime = {4}\n" +
                           "  Current time:        {5}\n" +
                           "  Elapsed time:        {6}\n" +
                           "  Sleep interval (ms): {7}",
                           AppDomain.GetCurrentThreadId(),
                           System.Threading.Thread.CurrentThread.Name,
                           s, d, requestEnqueueTime,
                           now,
                           now.Subtract(requestEnqueueTime),
                           sleepInterval );

        // Do the sleep.
        Thread.Sleep(sleepInterval);

        // Note that we're done (displaying the thread id/name & sleep
        // interval so that this output can be correlated to the previous
        // bit of output before the sleep.
        //
        Console.WriteLine( "CallbackTwo returning:\n" +
                           "  Thread id:            {0}\n" +
                           "  Thread name:          {1}\n" +
                           "  Sleep interval (ms):  {2}",
                           AppDomain.GetCurrentThreadId(),
                           System.Threading.Thread.CurrentThread.Name,
                           sleepInterval );
    }
}
