This directory contains 3 versions of a custom ASP.NET HTTP handler
that demonstrate using the custom thread pool for building async
handlers.

* ContextViewer.ashx: a normal, synchronous IHttpHandler implementation (baseline).

* AsyncContextViewer.ashx: IHttpAsyncHandler implementation using built-in thread pool.

* AsyncContextViewer2.ashx: IHttpAsyncHandler implementation using my custom
  thread pool (shows how to initialize the pool so that it propogates http
  context, call context, and thread principal; which are all off by default).

Each version of the handler displays a bit of text when the handler begins executing,
the displays more text periodically until the output is completed (1 second intervals
for a total of 5 seconds).

To test thread principal propogation, I've got a web.config that
enables/forces forms auth, and a corresponding login page (since it's a
handler, you have to exit the browser to clear the cookie :-).  The hashed
passwords in web.config are the specified principal's names in all lower
case ("larry", etc).

To test:
(1) Build the ThreadPool.dll library assembly and place a copy of it in
    the .\bin subdirectory where the .ASHX files reside (you'll need to
    create the .\bin directory).
(2) Map a virtual directory to the location where the ASHX files reside.
(3) Use a browser to browse to one of the handlers.
(4) Use web.config to enable/disable authentication in order to test
    principal propogation of different clients.