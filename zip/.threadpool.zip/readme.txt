Directory contents:

.\ThreadPool	Library assembly containing the custom
		thread pool implementation.

.\public

  .\TestApp	Console application that demonstrates some
		of the the thread pool's features.

  .\handlers	3 http handlers used used to test the pool
		in a web context.  Refer to the readme.txt
		in this directory for more details.
